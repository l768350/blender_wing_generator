# Bird Wing Rig Builder

Version: 0.54.0  
Target Blender version: 5.2.0 or newer compatible 5.2 builds

## Install

1. Open Blender and go to **Edit > Preferences > Add-ons**.
2. Open the install menu and choose **Install from Disk**.
3. Select `BlenderWingGenerator_0.54.0.zip`.
4. Enable **Bird Wing Rig Builder** in the add-ons list.
5. Find its controls in **3D Viewport > Sidebar (N) > Wing Model**.

This is a packaged legacy add-on. It keeps the original script logic and `bl_info` metadata; no third-party Python dependencies are bundled or required by the source imports.
