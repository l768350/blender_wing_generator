# Blender Wing Generator

Version: 0.54.0  
Target Blender version: 5.2.0 or newer compatible 5.2 builds

## Install

1. Drag the ZIP file into a Blender window.
2. If Blender does not start installation automatically, open **Edit > Preferences > Add-ons**, choose **Install from Disk**, and select the ZIP file.
3. Enable **Blender Wing Generator** in the add-ons list.
4. Find the controls in **3D Viewport > Sidebar (N) > Blender Wing Generator**.

The add-on name shown in Blender, its sidebar tab, and its panel header are all **Blender Wing Generator**. The original modeling and rigging logic has not otherwise been changed.
